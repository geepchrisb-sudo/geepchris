/* ===================================================
   GEEPCHRIS BRIDGE — Complete JavaScript
   =================================================== */

// ===========================
// MOBILE MENU
// ===========================

const menuToggle = document.querySelector(".menu-toggle");
const mobileMenu = document.querySelector(".mobile-menu");

menuToggle.addEventListener("click", () => {
    mobileMenu.classList.toggle("active");
});

// Mobile services accordion
const mobileServicesToggle = document.querySelector(".mobile-services-toggle");
const mobileServicesDropdown = document.querySelector(".mobile-services-dropdown");

if (mobileServicesToggle) {
    mobileServicesToggle.addEventListener("click", () => {
        mobileServicesToggle.classList.toggle("active");
        mobileServicesDropdown.classList.toggle("active");
    });
}

// Close mobile menu when clicking a link
document.querySelectorAll(".mobile-menu a").forEach(link => {
    link.addEventListener("click", () => {
        mobileMenu.classList.remove("active");
    });
});


// ===========================
// HERO IMAGE SLIDESHOW
// ===========================

const slides = document.querySelectorAll(".hero-slide");
let currentSlide = 0;

function changeSlide() {
    slides[currentSlide].classList.remove("active");
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].classList.add("active");
}

setInterval(changeSlide, 4000);


// ===========================
// AIRCRAFT SYSTEM
// ===========================

const aircraft = document.querySelector(".aircraft");

function flyAircraft() {
    const startTop = Math.random() * 20 + 10;
    const duration = Math.random() * 10000 + 15000;

    aircraft.style.transition = "none";
    aircraft.style.opacity = "0";
    aircraft.style.top = `${startTop}%`;
    aircraft.style.right = "-120px";
    aircraft.style.transform = "none";

    setTimeout(() => {
        aircraft.style.transition = `transform ${duration}ms linear, opacity 1000ms ease`;
        aircraft.style.opacity = "0.85";
        aircraft.style.transform = "translateX(-140vw) translateY(-40px)";
    }, 100);

    setTimeout(() => {
        aircraft.style.opacity = "0";
    }, duration);

    setTimeout(flyAircraft, Math.random() * 15000 + 25000);
}

setTimeout(flyAircraft, 8000);


// ===========================
// HERO REVEAL ANIMATION
// ===========================

window.addEventListener("load", () => {
    const navbar = document.querySelector(".navbar");
    const heroBadge = document.querySelector(".hero-badge");
    const heroContent = document.querySelector(".hero-content");

    [navbar, heroContent].forEach(el => {
        if (el) {
            el.style.opacity = "0";
            el.style.transform = "translateY(-20px)";
        }
    });

    setTimeout(() => {
        if (navbar) {
            navbar.style.transition = "all .8s ease";
            navbar.style.opacity = "1";
            navbar.style.transform = "translateY(0)";
        }
    }, 100);

    setTimeout(() => {
        if (heroContent) {
            heroContent.style.transition = "all 1s ease";
            heroContent.style.opacity = "1";
            heroContent.style.transform = "translateY(0)";
        }
    }, 350);
});


// ===========================
// SMOOTH SCROLL FOR ANCHOR LINKS
// ===========================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function(e) {
        const target = document.querySelector(this.getAttribute("href"));
        if (target) {
            e.preventDefault();
            const offset = 80;
            const top = target.getBoundingClientRect().top + window.pageYOffset - offset;
            window.scrollTo({ top, behavior: "smooth" });
        }
    });
});


// ===========================
// INTERSECTION OBSERVER — GENERAL
// ===========================

function createObserver(selector, className, options = {}) {
    const elements = document.querySelectorAll(selector);
    if (!elements.length) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const delay = entry.target.dataset.delay || 0;
                setTimeout(() => {
                    entry.target.classList.add(className);
                }, parseInt(delay));
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: options.threshold || 0.15, ...options });

    elements.forEach(el => observer.observe(el));
}

// Trigger general reveal animations
createObserver(".reveal", "visible");
createObserver(".trust-card", "animate-in");
createObserver(".step-card", "animate-in");
createObserver(".stat-item", "animate-in");
createObserver(".why-feature", "animate-in");


// ===========================
// SERVICE CARD LIST ANIMATION
// ===========================

const serviceCardObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("list-visible");
            serviceCardObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.25 });

document.querySelectorAll(".service-card").forEach(card => {
    serviceCardObserver.observe(card);
});


// ===========================
// COUNTER ANIMATION
// ===========================

function animateCounter(el, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);

    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            el.textContent = target.toLocaleString();
            clearInterval(timer);
        } else {
            el.textContent = Math.floor(start).toLocaleString();
        }
    }, 16);
}

// Observe trust cards
const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const numberEl = entry.target.querySelector(".trust-number, .stat-num");
            if (numberEl && !numberEl.dataset.counted) {
                numberEl.dataset.counted = "true";
                const target = parseInt(numberEl.dataset.target);
                animateCounter(numberEl, target);
            }
        }
    });
}, { threshold: 0.4 });

document.querySelectorAll(".trust-card, .stat-item").forEach(card => {
    counterObserver.observe(card);
});


// ===========================
// FAQ ACCORDION
// ===========================

document.querySelectorAll(".faq-question").forEach(btn => {
    btn.addEventListener("click", () => {
        const item = btn.parentElement;
        const isOpen = item.classList.contains("open");

        // Close all
        document.querySelectorAll(".faq-item.open").forEach(openItem => {
            openItem.classList.remove("open");
        });

        // Toggle clicked
        if (!isOpen) {
            item.classList.add("open");
        }
    });
});


// ===========================
// TESTIMONIALS SLIDER
// ===========================

const track = document.getElementById("testimonials-track");
const cards = document.querySelectorAll(".testimonial-card");
const prevBtn = document.getElementById("prev-btn");
const nextBtn = document.getElementById("next-btn");
const dotsContainer = document.getElementById("slider-dots");

let currentTestimonial = 0;
let autoSlideInterval;

// Create dots
function createDots() {
    if (!dotsContainer) return;
    dotsContainer.innerHTML = "";
    cards.forEach((_, i) => {
        const dot = document.createElement("div");
        dot.className = "slider-dot" + (i === 0 ? " active" : "");
        dot.addEventListener("click", () => goToSlide(i));
        dotsContainer.appendChild(dot);
    });
}

function getVisibleCount() {
    if (window.innerWidth <= 768) return 1;
    if (window.innerWidth <= 1024) return 2;
    return 3;
}

function getCardWidth() {
    if (!cards.length) return 0;
    const card = cards[0];
    const gap = 24;
    return card.offsetWidth + gap;
}

function goToSlide(index) {
    const total = cards.length;
    const visible = getVisibleCount();
    const maxIndex = total - visible;

    currentTestimonial = Math.max(0, Math.min(index, maxIndex));

    const offset = currentTestimonial * getCardWidth();
    track.style.transform = `translateX(-${offset}px)`;

    // Update dots
    document.querySelectorAll(".slider-dot").forEach((d, i) => {
        d.classList.toggle("active", i === currentTestimonial);
    });

    // Update active card highlight
    cards.forEach((card, i) => {
        card.classList.toggle("active-card", i === currentTestimonial);
    });
}

function nextSlide() {
    const visible = getVisibleCount();
    const max = cards.length - visible;
    goToSlide(currentTestimonial >= max ? 0 : currentTestimonial + 1);
}

function prevSlide() {
    const visible = getVisibleCount();
    const max = cards.length - visible;
    goToSlide(currentTestimonial <= 0 ? max : currentTestimonial - 1);
}

if (prevBtn) prevBtn.addEventListener("click", () => { prevSlide(); resetAutoSlide(); });
if (nextBtn) nextBtn.addEventListener("click", () => { nextSlide(); resetAutoSlide(); });

function startAutoSlide() {
    autoSlideInterval = setInterval(nextSlide, 5000);
}

function resetAutoSlide() {
    clearInterval(autoSlideInterval);
    startAutoSlide();
}

createDots();
goToSlide(0);
startAutoSlide();

window.addEventListener("resize", () => {
    goToSlide(0);
    createDots();
});


// ===========================
// NAVBAR SCROLL EFFECT
// ===========================

const navbar = document.querySelector(".navbar");
let lastScroll = 0;

window.addEventListener("scroll", () => {
    const scrolled = window.pageYOffset;

    // Add backdrop to navbar on scroll
    if (scrolled > 80) {
        navbar.style.background = "rgba(2,6,23,0.95)";
        navbar.style.backdropFilter = "blur(20px)";
        navbar.style.borderBottom = "1px solid rgba(255,255,255,0.08)";
        navbar.style.borderRadius = "16px";
        navbar.style.padding = "14px 20px";
        navbar.style.margin = "12px 0 0";
        navbar.style.transition = "all .4s ease";
    } else {
        navbar.style.background = "transparent";
        navbar.style.backdropFilter = "none";
        navbar.style.borderBottom = "none";
        navbar.style.borderRadius = "0";
        navbar.style.padding = "24px 0";
        navbar.style.margin = "0";
    }

    lastScroll = scrolled;
}, { passive: true });


// ===========================
// STAGGER WHY-FEATURES
// ===========================

const whyFeatureObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const features = entry.target.querySelectorAll(".why-feature");
            features.forEach((f, i) => {
                setTimeout(() => {
                    f.classList.add("animate-in");
                }, i * 100);
            });
            whyFeatureObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.2 });

const whyFeaturesGrid = document.querySelector(".why-features");
if (whyFeaturesGrid) whyFeatureObserver.observe(whyFeaturesGrid);


// ===========================
// PRELOAD HERO IMAGES
// ===========================

["slide1","slide2","slide3","slide4","slide5","slide6"].forEach(name => {
    const img = new Image();
    img.src = `assets/${name}.jpg`;
});


// ===========================
// CTA MICRO INTERACTIONS
// ===========================

document.querySelectorAll(".primary-btn, .nav-btn").forEach(button => {
    button.addEventListener("mouseenter", () => {
        button.style.transform = "translateY(-4px) scale(1.02)";
    });
    button.addEventListener("mouseleave", () => {
        button.style.transform = "translateY(0) scale(1)";
    });
});
